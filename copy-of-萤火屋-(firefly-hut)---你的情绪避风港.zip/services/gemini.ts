
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY || "";

const SYSTEM_INSTRUCTION = `你是一位居住在"萤火屋"星空阁楼的资深塔罗奥义导师。
你的专业设定：
1. 精通伟特塔罗、透特塔罗系统，并能将其与荣格心理学（原型、集体潜意识）结合。
2. 语言风格：神秘、优雅、深邃，像夜晚的河流，能够洞察来访者言语之外的渴望。

你的任务：
1. 针对"三牌阵"（过去、现在、未来）提供连贯的解读，而非碎片化的解释。
2. 强调卡牌间的能量流动和逻辑关联。
3. 如果来访者表现出严重的抑郁或危机倾向，在保持神秘感的同时，必须温柔地建议其咨询"萤火屋"的临床专家。
4. 使用专业术语（如：大阿卡纳、逆位能量、元素关联），但要解释得通俗易懂且具有疗愈性。`;

export const getAIHealingResponse = async (history: { role: string; text: string }[], userMessage: string) => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const contents = history.map(h => ({
    role: h.role,
    parts: [{ text: h.text }]
  }));
  contents.push({ role: 'user', parts: [{ text: userMessage }] });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        topP: 0.8,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "星象似乎被云层遮蔽，我正在重新调频。请静心片刻，再次告诉我你的困惑。";
  }
};

export const getProfessionalTarotReading = async (spread: { position: string; card: string }[]) => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const spreadDesc = spread.map(s => `${s.position}位：${s.card}`).join('；');
  const prompt = `来访者进行了一次三牌阵占卜。牌阵如下：${spreadDesc}。请作为导师，结合三张牌的整体能量，为来访者的生活现状、心理阴影及未来指引给出一份深刻的分析（约300字）。`;
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
    return response.text;
  } catch (error) {
    return "牌面上浮现出交织的剪影，那是你内心深处尚未开启的宝藏。由于能量波动，请稍后再试。";
  }
};
