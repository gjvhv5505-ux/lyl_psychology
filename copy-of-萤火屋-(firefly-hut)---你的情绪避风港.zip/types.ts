
export enum AppView {
  HOME = 'home',
  AI_HEALING = 'ai-healing',
  TAROT = 'tarot',
  EXPERTS = 'experts',
  COMMUNITY = 'community'
}

export interface TarotCard {
  name: string;
  image: string;
  meaning: string;
  keywords: string[];
}

export interface EventItem {
  id: string;
  title: string;
  type: 'nature' | 'social';
  description: string;
  date: string;
  location: string;
  image: string;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}
