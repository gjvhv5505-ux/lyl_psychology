
import React, { useState, useRef, useEffect } from 'react';
import { AppView } from '../types';

interface MusicPlayerProps {
  currentView: AppView;
}

const VIEW_MUSIC_MAP: Record<AppView, { url: string; label: string }> = {
  [AppView.HOME]: {
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    label: '林间钢琴：晨雾'
  },
  [AppView.AI_HEALING]: {
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3',
    label: '冥想钢琴：流泉'
  },
  [AppView.TAROT]: {
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3',
    label: '星空钢琴：低语'
  },
  [AppView.EXPERTS]: {
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    label: '高能钢琴：同频'
  },
  [AppView.COMMUNITY]: {
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    label: '轻快钢琴：漫步'
  },
};

const MusicPlayer: React.FC<MusicPlayerProps> = ({ currentView }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.12);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentTrack = VIEW_MUSIC_MAP[currentView];

  useEffect(() => {
    if (audioRef.current) {
      const wasPlaying = isPlaying;
      
      const fadeOut = setInterval(() => {
        if (audioRef.current && audioRef.current.volume > 0.02) {
          audioRef.current.volume -= 0.02;
        } else {
          clearInterval(fadeOut);
          if (audioRef.current) {
            audioRef.current.src = currentTrack.url;
            audioRef.current.load();
            audioRef.current.volume = volume;
            if (wasPlaying) {
              audioRef.current.play().catch(e => console.log("播放自动触发受阻"));
            }
          }
        }
      }, 30);
      
      return () => clearInterval(fadeOut);
    }
  }, [currentView]);

  const togglePlay = () => {
    if (isPlaying) {
      audioRef.current?.pause();
    } else {
      audioRef.current?.play().catch(e => console.log("播放错误", e));
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="flex items-center gap-3 glass px-4 py-2 rounded-full border border-white/10 shadow-lg">
      <audio 
        ref={audioRef}
        loop 
        src={currentTrack.url}
      />
      
      <div className="flex flex-col">
        <div className="flex gap-1 items-end h-3 mb-1">
          {[1, 2, 3, 4, 5].map((i) => (
            <div 
              key={i} 
              className={`w-0.5 bg-emerald-400/60 rounded-full transition-all duration-700 ${
                isPlaying ? 'animate-pulse' : 'h-0.5'
              }`}
              style={{ 
                animationDelay: `${i * 0.3}s`,
                height: isPlaying ? `${20 + Math.random() * 60}%` : '15%' 
              }}
            ></div>
          ))}
        </div>
        <span className="text-[9px] text-emerald-400/60 font-medium tracking-tight truncate w-24">
          {isPlaying ? currentTrack.label : '轻音乐已静音'}
        </span>
      </div>

      <div className="h-6 w-[1px] bg-white/10 mx-1"></div>

      <button 
        onClick={togglePlay}
        className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
          isPlaying ? 'bg-emerald-600/10 text-emerald-300' : 'bg-white/5 text-gray-500'
        }`}
        title={isPlaying ? '暂停' : '播放'}
      >
        {isPlaying ? (
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
        ) : (
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5 ml-0.5"><path d="M8 5v14l11-7z"/></svg>
        )}
      </button>

      <div className="hidden md:flex items-center gap-2">
        <span className="text-[10px] opacity-40">🎹</span>
        <input 
          type="range" 
          min="0" 
          max="0.5" 
          step="0.01" 
          value={volume}
          onChange={(e) => {
            const v = parseFloat(e.target.value);
            setVolume(v);
            if (audioRef.current) audioRef.current.volume = v;
          }}
          className="w-12 h-0.5 bg-emerald-950 rounded-lg appearance-none cursor-pointer accent-emerald-500/50"
        />
      </div>
    </div>
  );
};

export default MusicPlayer;
