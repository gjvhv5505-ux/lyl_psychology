
import React from 'react';
import { AppView } from '../types';

interface NavbarProps {
  activeView: AppView;
  onNavigate: (view: AppView) => void;
}

const Navbar: React.FC<NavbarProps> = ({ activeView, onNavigate }) => {
  const navItems = [
    { view: AppView.HOME, icon: '🌲', label: '庄园' },
    { view: AppView.AI_HEALING, icon: '🏡', label: '聊愈' },
    { view: AppView.TAROT, icon: '🔮', label: '启示' },
    { view: AppView.EXPERTS, icon: '⚡', label: '加BUFF' },
    { view: AppView.COMMUNITY, icon: '🎷', label: '狂欢' },
  ];

  return (
    <nav className="fixed bottom-4 md:bottom-8 left-1/2 -translate-x-1/2 w-[92%] max-w-xl glass rounded-[35px] md:rounded-[45px] p-2 md:p-3 flex justify-around items-center shadow-3xl z-50 border border-white/40">
      {navItems.map((item) => (
        <button
          key={item.view}
          onClick={() => onNavigate(item.view)}
          className={`flex flex-col items-center py-2 md:py-3 px-1 md:px-3 rounded-[24px] md:rounded-[28px] transition-all duration-500 min-w-[55px] md:min-w-[70px] ${
            activeView === item.view 
              ? 'bg-emerald-900 text-emerald-50 scale-105 md:scale-110 shadow-2xl -translate-y-1 md:-translate-y-2' 
              : 'text-emerald-950/40 hover:text-emerald-900'
          }`}
        >
          <span className="text-xl md:text-2xl mb-1">{item.icon}</span>
          <span className="text-[9px] md:text-[10px] font-bold tracking-tighter whitespace-nowrap">{item.label}</span>
        </button>
      ))}
    </nav>
  );
};

export default Navbar;
