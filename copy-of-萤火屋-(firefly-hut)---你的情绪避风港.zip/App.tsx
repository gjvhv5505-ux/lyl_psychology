
import React, { useState } from 'react';
import { AppView } from './types';
import Navbar from './components/Navbar';
import MusicPlayer from './components/MusicPlayer';
import Home from './views/Home';
import AIHealingRoom from './views/AIHealingRoom';
import TarotRoom from './views/TarotRoom';
import ExpertConnect from './views/ExpertConnect';
import Community from './views/Community';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.HOME);

  return (
    <div className="min-h-screen deep-forest-gradient relative flex flex-col text-[#064e3b]">
      {/* Morning Forest Mist Bar - Responsive height/text */}
      <div className="bg-emerald-950/10 text-emerald-900 text-[10px] py-1.5 md:py-2 px-4 md:px-6 text-center backdrop-blur-xl border-b border-white/20 flex justify-between items-center z-50">
        <div className="flex items-center gap-1.5 truncate">
          <span className="animate-pulse shrink-0">🍃</span>
          <span className="font-bold opacity-80 truncate">林间：松针和泥土的清香...</span>
        </div>
        <button 
          onClick={() => setCurrentView(AppView.EXPERTS)}
          className="bg-emerald-800 hover:bg-emerald-900 text-emerald-50 px-3 py-1 rounded-full text-[9px] md:text-[10px] transition-all shadow-lg active:scale-95 flex items-center gap-1 shrink-0 ml-2"
        >
          <span className="whitespace-nowrap">开启加BUFF模式</span>
          <span className="text-[8px]">→</span>
        </button>
      </div>

      <header className="p-4 md:p-10 flex justify-between items-center z-40">
        <div className="flex items-center gap-3 md:gap-5">
          <div className="w-12 h-12 md:w-16 md:h-16 bg-white leaf-radius flex items-center justify-center shadow-xl border border-emerald-100 relative group overflow-hidden">
            <span className="text-2xl md:text-4xl z-10 group-hover:scale-125 transition-transform">🌲</span>
            <div className="absolute inset-0 bg-emerald-50 opacity-40"></div>
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl md:text-3xl font-cursive text-emerald-950 tracking-widest leading-none">萤火屋</h1>
            <span className="text-[8px] md:text-[10px] text-emerald-700 font-bold tracking-[0.2em] md:tracking-[0.3em] uppercase mt-1 md:mt-2">The Emerald Sanctuary</span>
          </div>
        </div>
        <MusicPlayer currentView={currentView} />
      </header>

      <main className="flex-1 overflow-y-auto pb-32 md:pb-40 px-4 md:px-10 max-w-7xl mx-auto w-full">
        {renderView(currentView, setCurrentView)}
      </main>

      <Navbar activeView={currentView} onNavigate={setCurrentView} />

      {/* Forest Background Elements */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-5%] w-[40%] h-[100%] light-shaft opacity-30"></div>
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-emerald-400/10 blur-[150px] rounded-full"></div>
      </div>
    </div>
  );
};

function renderView(view: AppView, setView: (v: AppView) => void) {
  switch (view) {
    case AppView.HOME: return <Home setView={setView} />;
    case AppView.AI_HEALING: return <AIHealingRoom />;
    case AppView.TAROT: return <TarotRoom setView={setView} />;
    case AppView.EXPERTS: return <ExpertConnect />;
    case AppView.COMMUNITY: return <Community />;
    default: return <Home setView={setView} />;
  }
}

export default App;
