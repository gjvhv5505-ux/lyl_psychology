
import React from 'react';
import { AppView } from '../types';

interface HomeProps {
  setView: (view: AppView) => void;
}

const Home: React.FC<HomeProps> = ({ setView }) => {
  return (
    <div className="py-4 md:py-6 space-y-12 md:space-y-20 animate-fadeIn relative">
      
      {/* 1. Healing Manifesto Hero */}
      <section className="text-center space-y-6 md:space-y-8 relative">
        <div className="flex justify-center gap-2 md:gap-4 flex-wrap">
          <span className="bg-emerald-800/10 text-emerald-800 px-3 py-1.5 md:px-5 md:py-2 rounded-full text-[9px] md:text-[10px] font-bold border border-emerald-200 shadow-sm backdrop-blur-md">
            🛡️ 隐私加密守护
          </span>
          <span className="bg-orange-800/10 text-orange-800 px-3 py-1.5 md:px-5 md:py-2 rounded-full text-[9px] md:text-[10px] font-bold border border-orange-200 shadow-sm backdrop-blur-md">
            🩺 医疗绿色通道
          </span>
        </div>
        
        <div className="space-y-4">
          <h2 className="text-4xl md:text-8xl font-light text-emerald-950 leading-tight">
            在这里，<br/>
            <span className="font-cursive text-emerald-700 underline decoration-emerald-200/50 decoration-wavy">重装灵魂系统</span>
          </h2>
          <p className="max-w-3xl mx-auto text-emerald-900/70 font-light text-base md:text-xl leading-relaxed px-2">
            “萤火屋”是由<span className="text-emerald-900 font-bold px-1">国家持证大神</span>与专家共建的高能实验室。无论系统报错多严重，我们都有硬核方案带你重写底层逻辑。
          </p>
        </div>
      </section>

      {/* 2. Professional Credentials Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6 px-2">
        {[
          { icon: '⚡', label: '高能大神', desc: '1V1 组队重装' },
          { icon: '🕰️', label: '24/7 守护', desc: 'AI人工双重' },
          { icon: '🏥', label: '医疗直连', desc: '极速对标医生' },
          { icon: '🔒', label: '绝对私密', desc: '森林保密契约' }
        ].map((item, i) => (
          <div key={i} className="bg-white/50 backdrop-blur-sm p-4 md:p-6 rounded-[25px] md:rounded-[40px] border border-white flex flex-col items-center text-center space-y-1 hover:bg-white transition-all shadow-sm">
            <span className="text-2xl md:text-3xl mb-1">{item.icon}</span>
            <h4 className="text-emerald-950 font-bold text-xs md:text-sm">{item.label}</h4>
            <p className="text-[9px] md:text-[10px] text-emerald-800/50 leading-tight">{item.desc}</p>
          </div>
        ))}
      </div>

      {/* 3. The Central Card - Healing Theme */}
      <div className="bg-white/95 p-6 md:p-16 rounded-[40px] md:rounded-[80px] border-2 md:border-4 border-white shadow-xl relative overflow-hidden group">
        <div className="relative z-10 flex flex-col lg:flex-row items-center gap-8 md:gap-16">
          <div className="flex-1 space-y-6 md:space-y-10">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-orange-500 font-bold text-[10px] uppercase tracking-[0.2em]">
                <span className="w-4 md:w-8 h-[1px] bg-orange-200"></span>
                <span>Our Sanctuary</span>
              </div>
              <h3 className="text-2xl md:text-4xl text-emerald-950 font-medium">看，那是我们的避风港</h3>
              <p className="text-emerald-800/80 text-base md:text-lg font-light leading-relaxed">
                听，壁炉里的柴火正噼啪作响。在这里，所谓的“病”只是系统暂时需要升级，而我们是陪你升级的大神。
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 md:gap-5 w-full">
              <button 
                onClick={() => setView(AppView.EXPERTS)}
                className="bg-emerald-800 text-white px-8 py-4 md:px-12 md:py-5 rounded-[20px] md:rounded-[30px] text-sm font-bold shadow-xl active:scale-95"
              >
                和高能大神加个BUFF
              </button>
              <button 
                onClick={() => setView(AppView.AI_HEALING)}
                className="bg-orange-50 text-orange-800 border-2 border-orange-100 px-8 py-4 md:px-12 md:py-5 rounded-[20px] md:rounded-[30px] text-sm font-bold active:scale-95 shadow-sm"
              >
                和树屋AI聊聊
              </button>
            </div>
          </div>
          
          <div className="relative w-full lg:w-[480px] aspect-video sm:aspect-[4/3] rounded-[30px] md:rounded-[60px] overflow-hidden shadow-xl border-4 md:border-[16px] border-white shrink-0">
            <img 
              src="https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&q=80&w=800" 
              className="w-full h-full object-cover" 
              alt="Cozy Cabin"
            />
          </div>
        </div>
      </div>

      {/* 4. Scenes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-10">
        {[
          { title: '星空阁楼', view: AppView.TAROT, img: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?auto=format&fit=crop&q=80&w=400', desc: '看繁星掠过，抽取一份来自潜意识的科学投影。' },
          { title: '灵魂实验室', view: AppView.EXPERTS, img: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=400', desc: '每一位均为硬核主理人，为你重构底层驱动。' },
          { title: '山间狂欢', view: AppView.COMMUNITY, img: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&q=80&w=800', desc: '社交动力学引导，在奔跑中重塑多巴胺。' }
        ].map(item => (
          <div 
            key={item.title}
            onClick={() => setView(item.view)}
            className="group bg-white/70 p-5 md:p-8 rounded-[35px] md:rounded-[60px] cursor-pointer border border-white transition-all shadow-sm active:scale-98"
          >
            <div className="h-40 md:h-56 mb-4 md:mb-8 rounded-[25px] md:rounded-[45px] overflow-hidden relative">
              <img src={item.img} className="w-full h-full object-cover" />
            </div>
            <h4 className="text-xl md:text-2xl font-medium text-emerald-950">{item.title}</h4>
            <p className="text-emerald-800/60 text-xs md:text-sm mt-2 leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
