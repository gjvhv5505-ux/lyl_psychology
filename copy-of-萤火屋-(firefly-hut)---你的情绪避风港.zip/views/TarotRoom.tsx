
import React, { useState, useEffect } from 'react';
import { getProfessionalTarotReading } from '../services/gemini';
import { AppView } from '../types';

interface TarotRoomProps {
  setView: (view: AppView) => void;
}

const MASTER_GUIDES = [
  { id: 'selina', name: '萨琳娜', title: '荣格分析占卜师', icon: '🌙', bio: '擅长通过塔罗透视潜意识投影。' },
  { id: 'elias', name: '以利亚', title: '古典奥义学者', icon: '⚖️', bio: '严谨的逻辑与古老的智慧结合。' }
];

const ALL_CARDS = [
  { name: '愚者 (The Fool)', image: 'https://images.unsplash.com/photo-1601314167099-232775b3d6fd?auto=format&fit=crop&q=80&w=300' },
  { name: '魔术师 (The Magician)', image: 'https://images.unsplash.com/photo-1572947650440-e8a97ef050b2?auto=format&fit=crop&q=80&w=300' },
  { name: '女教皇 (The High Priestess)', image: 'https://images.unsplash.com/photo-1635431405786-4f6b6370428d?auto=format&fit=crop&q=80&w=300' },
  { name: '皇后 (The Empress)', image: 'https://images.unsplash.com/photo-1502481851512-e9e2529bbbf9?auto=format&fit=crop&q=80&w=300' },
  { name: '皇帝 (The Emperor)', image: 'https://images.unsplash.com/photo-1444491741275-3747c53c99b4?auto=format&fit=crop&q=80&w=300' },
  { name: '星星 (The Star)', image: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?auto=format&fit=crop&q=80&w=300' }
];

const TarotRoom: React.FC<TarotRoomProps> = ({ setView }) => {
  const [stage, setStage] = useState<'guide' | 'ritual' | 'reading'>('guide');
  const [selectedGuide, setSelectedGuide] = useState(MASTER_GUIDES[0]);
  const [spread, setSpread] = useState<{ position: string; card: any; isFlipped: boolean }[]>([
    { position: '过去 (Origins)', card: null, isFlipped: false },
    { position: '现在 (Present)', card: null, isFlipped: false },
    { position: '未来 (Path)', card: null, isFlipped: false }
  ]);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const startRitual = (guide: any) => {
    setSelectedGuide(guide);
    setStage('ritual');
    // 模拟洗牌仪式
    setTimeout(() => {
      const shuffled = [...ALL_CARDS].sort(() => Math.random() - 0.5);
      setSpread(prev => prev.map((s, i) => ({ ...s, card: shuffled[i] })));
    }, 2000);
  };

  const flipCard = (index: number) => {
    if (stage !== 'ritual') return;
    setSpread(prev => {
      const next = [...prev];
      next[index].isFlipped = true;
      return next;
    });
  };

  const getAllInterpretations = async () => {
    setIsLoading(true);
    const spreadData = spread.map(s => ({ position: s.position, card: s.card.name }));
    const analysis = await getProfessionalTarotReading(spreadData);
    setAiAnalysis(analysis || "星轨运行中出现了一丝扰动，请深呼吸，重新凝视牌面。");
    setIsLoading(false);
    setStage('reading');
  };

  useEffect(() => {
    if (spread.every(s => s.isFlipped) && stage === 'ritual') {
      getAllInterpretations();
    }
  }, [spread]);

  return (
    <div className="min-h-[80vh] flex flex-col items-center py-10 px-4 animate-fadeIn relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(13,20,40,1)_0%,rgba(6,78,59,1)_100%)] z-0"></div>
      <div className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] z-1"></div>

      <div className="relative z-10 w-full max-w-5xl space-y-12">
        
        {stage === 'guide' && (
          <div className="text-center space-y-12 py-20">
            <div className="space-y-4">
              <h2 className="text-4xl md:text-6xl font-cursive text-amber-100">启示祭坛</h2>
              <p className="text-emerald-100/60 tracking-widest uppercase text-xs">Choose Your Oracle Guide</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
              {MASTER_GUIDES.map(guide => (
                <div 
                  key={guide.id}
                  onClick={() => startRitual(guide)}
                  className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-[40px] cursor-pointer hover:bg-white/10 transition-all hover:border-amber-500/50 group"
                >
                  <span className="text-5xl block mb-4 group-hover:scale-110 transition-transform">{guide.icon}</span>
                  <h4 className="text-2xl text-amber-50 font-medium mb-1">{guide.name}</h4>
                  <p className="text-amber-500/80 text-[10px] font-bold uppercase tracking-widest mb-4">{guide.title}</p>
                  <p className="text-emerald-100/50 text-sm font-light leading-relaxed">{guide.bio}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {(stage === 'ritual' || stage === 'reading') && (
          <div className="space-y-16 py-10 animate-fadeIn">
            <header className="flex flex-col md:flex-row items-center justify-between gap-6 border-b border-white/10 pb-8">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-500/20 rounded-full flex items-center justify-center text-2xl border border-amber-500/30">
                  {selectedGuide.icon}
                </div>
                <div>
                  <p className="text-amber-100 font-bold">{selectedGuide.name} 正在引导你</p>
                  <p className="text-[10px] text-emerald-400/60 uppercase font-bold tracking-widest">Divine Resonance Ritual</p>
                </div>
              </div>
              <div className="text-emerald-100/40 text-[10px] tracking-widest uppercase">
                {stage === 'ritual' ? '请依次揭开你的命运之牌' : '星轨已定 · 正在解读'}
              </div>
            </header>

            {/* Spread Area */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 justify-items-center">
              {spread.map((item, idx) => (
                <div key={idx} className="flex flex-col items-center gap-6 group">
                  <span className="text-emerald-400/60 text-[10px] font-bold tracking-widest uppercase">{item.position}</span>
                  <div 
                    onClick={() => flipCard(idx)}
                    className={`relative w-48 h-80 cursor-pointer transition-all duration-1000 preserve-3d ${item.isFlipped ? 'rotate-y-180' : 'hover:-translate-y-4'}`}
                  >
                    {/* Card Back */}
                    <div className={`absolute inset-0 bg-[url('https://images.unsplash.com/photo-1572344070258-477042079018?auto=format&fit=crop&q=80&w=400')] bg-cover rounded-[20px] border-[6px] border-amber-900/50 shadow-2xl flex items-center justify-center backface-hidden`}>
                      <div className="absolute inset-0 bg-emerald-950/40 backdrop-blur-[2px]"></div>
                      <div className="relative z-10 w-24 h-24 border-2 border-amber-500/30 rounded-full flex items-center justify-center animate-pulse">
                        <span className="text-3xl">🌌</span>
                      </div>
                    </div>
                    {/* Card Front */}
                    <div className={`absolute inset-0 rounded-[20px] overflow-hidden border-[6px] border-amber-500/30 shadow-2xl rotate-y-180 backface-hidden bg-emerald-950`}>
                      {item.card && <img src={item.card.image} className="w-full h-full object-cover grayscale-[0.2]" alt={item.card.name} />}
                      <div className="absolute bottom-0 left-0 w-full bg-black/70 p-4 text-center border-t border-amber-500/20">
                        <p className="text-[10px] text-amber-500 font-bold uppercase truncate">{item.card?.name}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Analysis Area */}
            {stage === 'reading' && (
              <div className="max-w-3xl mx-auto space-y-8 animate-slideUp">
                <div className="bg-white/5 backdrop-blur-2xl p-10 rounded-[50px] border border-amber-500/20 shadow-inner relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-6 opacity-20 pointer-events-none group-hover:opacity-100 transition-opacity">
                    <span className="text-6xl text-amber-500">✨</span>
                  </div>
                  <h4 className="text-2xl text-amber-100 font-cursive mb-6 flex items-center gap-3">
                    <span className="w-10 h-[1px] bg-amber-500/50"></span>
                    全牌阵深度洞察
                  </h4>
                  {isLoading ? (
                    <div className="py-20 flex flex-col items-center gap-4">
                      <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
                      <p className="text-amber-100/40 text-xs font-bold uppercase animate-pulse">Gathering Divine Insights...</p>
                    </div>
                  ) : (
                    <p className="text-emerald-50/80 leading-relaxed font-light text-base md:text-lg whitespace-pre-wrap first-letter:text-4xl first-letter:font-cursive first-letter:text-amber-500 first-letter:mr-1">
                      {aiAnalysis}
                    </p>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row gap-5 justify-center">
                  <button 
                    onClick={() => { setStage('guide'); setSpread(prev => prev.map(s => ({ ...s, isFlipped: false, card: null }))); setAiAnalysis(null); }}
                    className="px-12 py-4 bg-white/5 border border-white/10 text-amber-100 rounded-full text-sm font-bold hover:bg-white/10 transition-all active:scale-95"
                  >
                    重置祭坛
                  </button>
                  <button 
                    onClick={() => setView(AppView.AI_HEALING)}
                    className="px-12 py-4 bg-amber-700 text-amber-50 rounded-full text-sm font-bold shadow-xl shadow-amber-950/50 hover:bg-amber-600 transition-all active:scale-95"
                  >
                    去聊愈室深谈
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <style>{`
        .preserve-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
        .animate-slideUp { animation: slideUp 1s ease-out forwards; }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default TarotRoom;
