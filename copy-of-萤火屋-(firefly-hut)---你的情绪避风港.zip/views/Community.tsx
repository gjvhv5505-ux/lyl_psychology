
import React from 'react';

interface Event {
  id: string;
  title: string;
  type: 'nature' | 'social';
  date: string;
  location: string;
  desc: string;
  image: string;
  leadTherapist: {
    name: string;
    icon: string;
    focus: string;
  };
  therapeuticGoal: string;
  tags: string[];
}

const Community: React.FC = () => {
  const events: Event[] = [
    {
      id: '1',
      title: '山间游玩：丁达尔追光计划',
      type: 'nature',
      date: '每周六 09:00',
      location: '庄园后山森林',
      desc: '在晨光熹微时出发，由专业户外疗愈师引导，通过森林浴、赤足行走感受自然的能量注入。',
      image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&q=80&w=800',
      leadTherapist: { name: '林叔', icon: '🌲', focus: '森林疗法' },
      therapeuticGoal: '缓解长期居家带来的社交退缩，激活感官。',
      tags: ['森林浴', '自然疗愈', '轻量徒步']
    },
    {
      id: '2',
      title: '灵魂蹦迪：萤火微醺之夜',
      type: 'social',
      date: '每周五 21:00',
      location: '庄园地下酒吧',
      desc: '拒绝尴尬的社交。在特制低酒精饮品和舒缓到激烈的旋律切换中，通过舞动彻底释放压抑的心灵。',
      image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&q=80&w=800',
      leadTherapist: { name: '阿力', icon: '🎷', focus: '多巴胺重塑' },
      therapeuticGoal: '通过高频社交运动，调节神经递质平衡。',
      tags: ['自由舞动', '微醺社交', '压力释放']
    }
  ];

  return (
    <div className="py-8 space-y-16 animate-fadeIn relative">
      <section className="text-center space-y-4">
        <h2 className="text-4xl font-cursive text-emerald-950">疗愈生活场</h2>
        <p className="text-emerald-700/70 text-base max-w-2xl mx-auto leading-relaxed italic">
          "走出封闭的房间，在山间与人群中重新找回呼吸的节奏。"
        </p>
      </section>

      <div className="grid grid-cols-1 gap-12">
        {events.map((event) => (
          <div key={event.id} className="relative group bg-white/60 rounded-[55px] overflow-hidden flex flex-col lg:flex-row shadow-2xl border border-white hover:bg-white transition-all duration-700">
            <div className="h-64 lg:h-auto lg:w-2/5 relative">
              <img src={event.image} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-emerald-900/5"></div>
            </div>
            <div className="p-8 lg:w-3/5 flex flex-col justify-between">
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <span className="bg-emerald-100 text-emerald-700 text-[10px] font-bold px-3 py-1 rounded-full uppercase">
                    {event.type === 'nature' ? '🍃 自然课' : '🎷 社交课'}
                  </span>
                  <span className="text-[10px] text-emerald-800 tracking-widest uppercase">📍 {event.location}</span>
                </div>
                <h3 className="text-2xl text-emerald-950 font-medium">{event.title}</h3>
                <p className="text-emerald-800/70 text-sm leading-relaxed">{event.desc}</p>
                <div className="flex items-center gap-3 bg-emerald-50/50 p-4 rounded-[25px]">
                  <span className="text-2xl">{event.leadTherapist.icon}</span>
                  <div>
                    <p className="text-xs font-bold">领队：{event.leadTherapist.name}</p>
                    <p className="text-[10px] text-emerald-600">{event.therapeuticGoal}</p>
                  </div>
                </div>
              </div>
              <div className="mt-8 flex items-center justify-between">
                <div className="flex gap-2">
                  {event.tags.map(t => (
                    <span key={t} className="text-[9px] text-emerald-400 font-bold">#{t}</span>
                  ))}
                </div>
                <button className="bg-emerald-800 text-white px-8 py-3 rounded-full text-xs font-bold hover:bg-emerald-900 shadow-lg transition-all">
                  立即加入
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Community;
