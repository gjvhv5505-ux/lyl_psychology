
import React from 'react';

const ExpertConnect: React.FC = () => {
  const masters = [
    { 
      name: 'Zero (零号)', 
      title: '首席游戏化疗愈师', 
      role: 'INFP | 副本攻略专家',
      credentials: '擅长处理：虚拟世界沉溺 / 现实社交恐惧',
      icon: '🎮',
      tags: ['游戏疗法', '二次元投影', 'NPC思维'],
      intro: '现实世界这个游戏太难玩了？别担心，我来帮你重排技能点，带你通关。',
      img: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=400',
      stats: { power: '98%', charm: '95%' }
    },
    { 
      name: 'K 博士', 
      title: '脑科学极客', 
      role: 'INTJ | 生物黑客',
      credentials: '擅长处理：重度抑郁 / 睡眠系统重装',
      icon: '⚡',
      tags: ['脑波干预', '生物节律', '药理骇客'],
      intro: '大脑只是一个精密的处理器。当它报错时，我们需要进入底层逻辑进行修正。',
      img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400',
      stats: { power: '99%', charm: '88%' }
    },
    { 
      name: 'Mona (莫娜)', 
      title: '潮流心理主理人', 
      role: 'ENFJ | 情绪造型师',
      credentials: '擅长处理：容貌焦虑 / 身份认同 / 恋爱脑',
      icon: '🛹',
      tags: ['滑板冥想', '街头艺术', '身体自洽'],
      intro: '拒绝白大褂和教条。在滑板场或涂鸦墙前，我们一起定义属于你的“酷”。',
      img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400',
      stats: { power: '92%', charm: '99%' }
    }
  ];

  return (
    <div className="py-8 space-y-16 animate-fadeIn relative">
      {/* 顶部标题 */}
      <section className="text-center space-y-6">
        <div className="inline-block px-6 py-2 bg-emerald-950/5 rounded-full border border-emerald-200">
           <span className="text-[10px] font-bold text-emerald-800 tracking-[0.3em] uppercase">Soul Reboot Lab</span>
        </div>
        <h2 className="text-4xl md:text-5xl font-light text-emerald-950">系统重装<span className="font-cursive text-emerald-600">实验室</span></h2>
        <p className="text-emerald-800/60 text-sm max-w-lg mx-auto leading-relaxed">
          不讲大道理，不穿白大褂。在这里，寻找能带你走出系统报错、重新满血复活的高能大神。
        </p>
      </section>

      {/* 紧急求助：系统崩溃模式 */}
      <div className="relative group mx-auto max-w-5xl">
        <div className="absolute inset-0 bg-orange-500/10 blur-[50px] rounded-[60px] opacity-0 group-hover:opacity-100 transition-opacity"></div>
        <div className="relative bg-emerald-950 text-white p-8 md:p-14 rounded-[45px] md:rounded-[65px] border-4 border-emerald-900 shadow-2xl flex flex-col md:flex-row items-center gap-10 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-orange-500 to-transparent"></div>
          <div className="w-24 h-24 bg-orange-600 rounded-[30px] flex items-center justify-center text-5xl shadow-[0_0_30px_rgba(234,88,12,0.5)] animate-pulse shrink-0">
            🆘
          </div>
          <div className="flex-1 space-y-4 text-center md:text-left">
            <h3 className="text-2xl md:text-3xl font-bold tracking-tight text-orange-400">系统彻底崩溃：紧急介入</h3>
            <p className="text-emerald-50/60 text-base font-light">
              如果你感到“血条”即将清空，或者有极其痛苦的念头，请立即强制介入。专业精神科医生 24H 在线待命，直接接通医疗绿色通道。
            </p>
            <button className="bg-orange-600 hover:bg-orange-700 text-white px-10 py-4 rounded-[20px] text-sm font-bold shadow-xl transition-all active:scale-95 flex items-center gap-3 mx-auto md:mx-0">
              <span>立即强制连接医生</span>
              <span className="animate-ping text-[8px]">●</span>
            </button>
          </div>
        </div>
      </div>

      {/* 角色选择网格 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8">
        {masters.map((m, i) => (
          <div key={i} className="group relative bg-white rounded-[45px] overflow-hidden border border-emerald-50 shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 flex flex-col h-full">
            {/* 角色形象 */}
            <div className="h-64 relative overflow-hidden">
              <img src={m.img} className="w-full h-full object-cover grayscale-[0.3] group-hover:grayscale-0 transition-all duration-700 group-hover:scale-110" alt={m.name} />
              <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6 flex justify-between items-end">
                <div>
                  <h4 className="text-2xl font-bold text-white">{m.name}</h4>
                  <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest">{m.role}</p>
                </div>
                <div className="text-3xl drop-shadow-lg">{m.icon}</div>
              </div>
            </div>

            {/* 属性与介绍 */}
            <div className="p-8 flex-1 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                   <div className="flex-1 space-y-1">
                      <div className="flex justify-between text-[8px] font-bold text-emerald-900/40 uppercase">
                        <span>Healing Power</span>
                        <span>{m.stats.power}</span>
                      </div>
                      <div className="h-1 bg-emerald-50 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500" style={{ width: m.stats.power }}></div>
                      </div>
                   </div>
                </div>
                
                <p className="text-sm text-emerald-900 font-medium leading-relaxed italic">
                  "{m.intro}"
                </p>

                <div className="space-y-2">
                  <p className="text-[10px] text-emerald-400 font-bold uppercase">Expertise</p>
                  <p className="text-xs text-emerald-800/60 leading-relaxed">{m.credentials}</p>
                </div>

                <div className="flex flex-wrap gap-2">
                  {m.tags.map(t => (
                    <span key={t} className="text-[9px] bg-emerald-950 text-emerald-50 px-3 py-1 rounded-full font-bold">#{t}</span>
                  ))}
                </div>
              </div>

              <button className="w-full bg-emerald-50 hover:bg-emerald-100 text-emerald-900 py-4 rounded-[25px] text-xs font-bold transition-all flex items-center justify-center gap-2 border border-emerald-200">
                <span>开启 1V1 系统扩容</span>
                <span className="opacity-40">→</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExpertConnect;
