
import React, { useState, useRef, useEffect } from 'react';
import { getAIHealingResponse } from '../services/gemini';
import { Message } from '../types';

const AIHealingRoom: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: '（你推开吱呀的木门，我正靠在窗边看晨雾漫过山谷）嘿，你来了。愿意跟我分享你的心事吗？' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg: Message = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);
    const response = await getAIHealingResponse(messages, input);
    setIsTyping(false);
    setMessages(prev => [...prev, { role: 'model', text: response || "我在听，你说出的每一个字，森林都会替你温柔保管。" }]);
  };

  return (
    <div className="flex flex-col h-[75vh] md:h-[78vh] max-w-3xl mx-auto animate-fadeIn relative">
      <div className="bg-white/80 rounded-[35px] md:rounded-[70px] flex-1 overflow-hidden flex flex-col border border-white shadow-2xl relative">
        <div className="p-4 md:p-8 border-b border-emerald-50/50 flex items-center justify-between bg-white/50 backdrop-blur-xl">
          <div className="flex items-center gap-3 md:gap-5">
            <div className="w-10 h-10 md:w-14 md:h-14 bg-emerald-100 rounded-[12px] md:rounded-[20px] flex items-center justify-center text-xl md:text-3xl">
              <span>🏡</span>
            </div>
            <div>
              <p className="text-base md:text-lg font-bold text-emerald-950 leading-tight">雾中树屋</p>
              <p className="text-[8px] md:text-[10px] text-emerald-500 font-bold uppercase tracking-widest">Mist Sanctuary</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 bg-emerald-50/80 px-4 py-1.5 rounded-full border border-emerald-100">
            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></div>
            <span className="text-[10px] font-bold text-emerald-800">深度疗愈</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 md:p-10 space-y-6 md:space-y-10 scrollbar-hide">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[92%] md:max-w-[85%] px-5 py-3 md:px-7 md:py-5 rounded-[25px] md:rounded-[35px] text-sm md:text-base leading-relaxed ${
                msg.role === 'user' 
                  ? 'bg-emerald-800 text-white rounded-tr-none' 
                  : 'bg-white text-emerald-950 rounded-tl-none border border-emerald-50'
              }`}>
                {msg.text}
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white/90 px-5 py-3 rounded-[25px] rounded-tl-none border border-emerald-50 flex gap-2">
                <div className="w-2 h-2 bg-emerald-300 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-emerald-300 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-2 h-2 bg-emerald-300 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
            </div>
          )}
          <div ref={scrollRef}></div>
        </div>

        <div className="p-4 md:p-8 bg-white/90 border-t border-emerald-50">
          <div className="flex gap-3 md:gap-5">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="落叶一样飘落的心事..."
              className="flex-1 bg-white border border-emerald-100 rounded-[25px] px-6 py-3.5 md:py-5 text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-emerald-100"
            />
            <button 
              onClick={handleSend}
              className="w-12 h-12 md:w-16 md:h-16 bg-emerald-800 text-white rounded-[20px] md:rounded-[30px] flex items-center justify-center transition-all active:scale-90"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" className="w-6 h-6 md:w-8 md:h-8"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIHealingRoom;
